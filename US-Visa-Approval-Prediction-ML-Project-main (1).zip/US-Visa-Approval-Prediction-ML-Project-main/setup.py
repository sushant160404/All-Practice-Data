from setuptools import find_packages, setup

setup(
    name="us_visa",
    version="0.0.1",
    author="Harshal Kumre",
    author_email="kumreharshalkumar@gmail.com",
    packages=find_packages()
)