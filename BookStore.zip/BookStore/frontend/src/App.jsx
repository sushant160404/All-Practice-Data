import React from "react";
import Navbar from "./components/Navbar";
import Banner1 from "./components/Banner1";

function App() {
  return (
    <>
      <Navbar />
      <Banner1 />
      <Footer />
    </>
  );
}

export default App;
