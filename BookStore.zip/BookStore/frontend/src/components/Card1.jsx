import React from 'react'

function Card1() {
  return (
    <div>
        <div>
            Notification
        </div>
      
    </div>
  )
}

export default Card1
