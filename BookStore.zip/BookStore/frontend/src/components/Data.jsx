import React from 'react'

function Data() {
  return (
    <div>
        
      
    </div>
  )
}

export default Data
