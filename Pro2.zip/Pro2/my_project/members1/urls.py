from django.urls import path
from . import views

urlpatterns = [
    path('members1/', views.members1, name='members1'),
    path('members1/details/<int:id>', views.details, name='details'),
]