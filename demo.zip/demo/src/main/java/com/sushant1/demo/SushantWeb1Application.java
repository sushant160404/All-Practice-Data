package com.sushant1.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SushantWeb1Application {

	public static void main(String[] args) {
		SpringApplication.run(SushantWeb1Application.class, args);
	}

}
