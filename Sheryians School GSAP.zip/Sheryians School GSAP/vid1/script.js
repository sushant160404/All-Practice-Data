gsap.to("#box1",{
	y:1000,
	delay:1,
	rotate:360
})

gsap.from("#box2",{
	x:1000,
	delay:2,
	backgroundColor: "blue",
	borderRadius:"50%"
})