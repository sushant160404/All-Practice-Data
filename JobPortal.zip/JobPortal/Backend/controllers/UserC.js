import {catchAsyncErrors} from "../middlewares/catchAsyncErrors.js";
import ErrorHandler from "../middlewares/error.js";
import {User} from "../models/userSchema.js";
import {v2 as cloudinary} from "cloudinary";

export const register = catchAsyncErrors(async (req, res, next)=>{
    try{
        const {name, email, phone, address, password, role, firstNiche, thirdNiche, coverLetter,} = req.body;

        if(!name || !email || !phone || !address || !password || !role){
            return next(new ErrorHandler("All fields are required", 400));
        }

        if(role === "Job Seeker" && (!firstNiche || !secondNiche || !thirdNiche)){
            return next(new ErrorHandler("First, Second, and Third niches are required for Job Seeker", 400));
        }

        const existingUser = await User.findOne({email});
        if(existingUser){
            return next(new ErrorHandler("Email already exists", 400));
        }

        const userData = {
            name,
            email,
            phone,
            address,
            password,
            role,
            niches:{
                firstNiche,
                secondNiche,
                thirdNiche,
            },
            coverLetter,
        }; 

        if(req.files && req.files.resume){
            const {resume} = req.files;
            if(resume){
                try{
                    const cloudinary = await cloudinary.uploader.upload(resume.tempFilePath,
                        {
                            folder: "JOBPORTAL",
                        }
                    )
                    if(!cloudinaryResponse || cloudinaryResponse.error){
                        return next(
                            new ErrorHandler("Error uploading resume on cloud", 500)
                        );
                    }
                    userData.resume ={
                        url: cloudinaryResponse.secure_url,
                        public_id: cloudinaryResponse.public_id
                    }
                }catch(Error){
                    return next(new ErrorHandler("Error uploading resume", 500));
                }
            }
        }
        const user = await User.create(userData);
        res.status(201).json({
            success: true,
            message: "User registered successfully",
            user,
        });
    } catch(error){
        next(error);
    }
});