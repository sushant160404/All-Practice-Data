import mongoose from "mongoose";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import validator from "validator";
import { required } from "nodemon/lib/config";

const userSchema = new mongoose.Schema({
    name:{
        type: String,
        required: true,
        minlength: [3,"Name must contain at least 3 characters"],
        maxlength: [50,"Name cannot exceed 50 characters"],
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        validate: [validator.isEmail, "Invalid email address"],
        maxlength: [50,"Email cannot exceed 50 characters"],
    },
    phone:{
        type: String,
        required: true,
        minlength: [10,"Phone number must contain at least 10 digits"],
        maxlength: [15,"Phone number cannot exceed 15 digits"],
    },
    address: {
        type: String,
        required: true,
        minlength: [10,"Address must contain at least 10 characters"],
        maxlength: [100,"Address cannot exceed 100 characters"],
    },
    niches: {
        firstNiche: String,
        secondNiche: String,
        thirdNiche: String
    },
    password:{
        type: String,
        required: true,
        minlength: [8,"Password must contain at least 8 characters"],
    },
    resume: {
        type: Buffer,
        public_id: String,
        url: String,
    },
    coverLetter: {
        type: String,
    },
    role:{
        type: String,
        required: true,
        enum: ["Job Seeker", "Employer"],
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

export const User = mongoose.model('User',userSchema);