from django.contrib import admin # type: ignore

# Register your models here.
