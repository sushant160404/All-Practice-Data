from django.urls import path # type: ignore
from . import views

urlpatterns = [
    path('member1/', views.member1, name='member1'),
    path('member2/', views.member2, name='member2'),
    path('member3/', views.member3, name='member3'),
]
