from django.db import models # type: ignore

# Create your models here.
