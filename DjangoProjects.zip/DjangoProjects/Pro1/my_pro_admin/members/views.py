from django.shortcuts import render # type: ignore
from django.http import HttpResponse # type: ignore
from django.template import loader # type: ignore
# Create your views here.

def member1(request):
    return HttpResponse("Hello, member1!")

def member2(request):
    return HttpResponse("Hello, member2!")

def member3(request):
    template=loader.get_template("myfirst.html") # type: ignore
    return HttpResponse(template.render())

