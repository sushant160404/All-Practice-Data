// import { useState } from 'react'
// import reactLogo from './assets/react.svg'
// import viteLogo from '/vite.svg'
// import './App.css'

// function App() {
//   const [count, setCount] = useState(0)

//   return (
//     <>
//       <div>
//         <a href="https://vitejs.dev" target="_blank">
//           <img src={viteLogo} className="logo" alt="Vite logo" />
//         </a>
//         <a href="https://react.dev" target="_blank">
//           <img src={reactLogo} className="logo react" alt="React logo" />
//         </a>
//       </div>
//       <h1>Vite + React</h1>
//       <div className="card">
//         <button onClick={() => setCount((count) => count + 1)}>
//           count is {count}
//         </button>
//         <p>
//           Edit <code>src/App.jsx</code> and save to test HMR
//         </p>
//       </div>
//       <p className="read-the-docs">
//         Click on the Vite and React logos to learn more
//       </p>
//     </>
//   )
// }

// export default App

import { useState } from "react";
import axios from "axios";

function App() {
  const [value2, setValue2] = useState({
    sizes: [],
    bedrooms: [],
  });
  const [price, setPrice] = useState("");

  const fetchValue = async () => {
    try {
      const res = await axios.post(
        "http://localhost:5000/api/predict/",
        value2
      );
      setPrice(res.data.results[0].predicted_price);
    } catch (error) {
      console.log(error.message);
    }
  };

  return (
    <>
    <div className="scroll-margin-inline-end"> 
      <h1 className="text-5xl mt-10 font-bold text-primary">
        Welcome to House Price Prediction
      </h1>
      <div className="flex gap-4 mt-4">
        <input
          type="number"
          value={value2.sizes}
          placeholder="Enter Size"
          className="input input-bordered input-accent w-full max-w-xs"
          onChange={(e) =>
            setValue2({ ...value2, sizes: [Number(e.target.value)] })
          }
        />
        <input
          type="number"
          value={value2.bedrooms}
          placeholder="Enter Bedroom"
          className="input input-bordered input-accent w-full max-w-xs"
          onChange={(e) =>
            setValue2({ ...value2, bedrooms: [Number(e.target.value)] })
          }
        />
        <button className="btn btn-accent" onClick={fetchValue}>
          Predict
        </button>
      </div>
      <div className="flex items-center w-full">
        <h1 className="text-5xl mt-10 font-bold underline">
          {`Predicted Price: ${price}`}
        </h1>
      </div>
      </div>
    </>
  );
}

export default App;
