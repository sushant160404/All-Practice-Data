import * as React from "react";

export default function StatCard({ icon, count, label }) {
  return (
    <div className="flex grow gap-9 max-md:mt-10">
      <img
        loading="lazy"
        src={icon}
        alt=""
        className="object-contain shrink-0 w-32 max-w-full rounded-none aspect-square"
      />
      <div className="flex flex-col flex-1 self-start mt-5">
        <div className="text-5xl font-semibold leading-tight text-slate-700 max-md:text-4xl">
          {count}
        </div>
        <div className="self-start mt-3 text-lg leading-8 text-slate-600">
          {label}
        </div>
      </div>
    </div>
  );
}
