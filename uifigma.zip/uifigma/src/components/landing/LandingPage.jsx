import * as React from "react";
import StatCard from "./StatCard";
import NavLink from "./NavLink";

export default function LandingPage() {
  const stats = [
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/730124931bad4e5a81ecd722de216101/72390a8e5f5cc92e93c74f0bbd14c2eeaa5f917a4c5858a9dee2558c2cc39d3c?apiKey=730124931bad4e5a81ecd722de216101&",
      count: "15k+",
      label: "Active user",
    },
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/730124931bad4e5a81ecd722de216101/61967e28d4ca8e88fa5afb79770fe54be3d378bdb4ddeba32ab56c9f8131d217?apiKey=730124931bad4e5a81ecd722de216101&",
      count: "30k",
      label: "Total Download",
    },
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/730124931bad4e5a81ecd722de216101/df11138318755c077b66ebedf7c70824a675f73d04bde0aef0062bee2a82f930?apiKey=730124931bad4e5a81ecd722de216101&",
      count: "10k",
      label: "Customer",
    },
  ];

  return (
    <div className="flex overflow-hidden flex-col bg-white">
      <div className="flex flex-col pr-1.5 pb-3 w-full max-md:max-w-full">
        <div className="flex gap-5 justify-between items-end w-full text-lg max-w-[1540px] max-md:max-w-full">
          <img
            loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/730124931bad4e5a81ecd722de216101/75f86e79642e3441869af0e0c8b97dc401bba415337b327a49e012da8a7cbec2?apiKey=730124931bad4e5a81ecd722de216101&"
            alt="Company Logo"
            className="object-contain shrink-0 self-stretch w-20 rounded-sm aspect-[0.75]"
          />
          <img
            loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/730124931bad4e5a81ecd722de216101/ea75737c8409f952005fb589697405de131f83e32bd05fe557ea842d953fa971?apiKey=730124931bad4e5a81ecd722de216101&"
            alt="Brand Image"
            className="object-contain shrink-0 mt-14 max-w-full aspect-[4.48] w-[179px] max-md:mt-10"
          />
          <div className="flex gap-6 mt-14 leading-8 text-right text-slate-700 max-md:mt-10">
            <NavLink hasDropdown>
              <div className="text-indigo-400">Home</div>
            </NavLink>
            <NavLink href="https://www.geeksforgeeks.org/100-days-of-machine-learning/?ref=dhm">
              About us
            </NavLink>
            <NavLink hasDropdown>Services</NavLink>
            <NavLink hasDropdown>Blog</NavLink>
            <NavLink>Contact us</NavLink>
          </div>
          <div className="flex gap-10 mt-11 font-bold text-indigo-400 max-md:mt-10">
            <button className="my-auto">Login</button>
            <button className="gap-2.5 px-8 py-4 rounded-2xl border border-indigo-400 border-solid max-md:px-5">
              Sign up
            </button>
          </div>
        </div>
        <div className="mt-24 max-md:mt-10 max-md:max-w-full">
          <div className="flex gap-5 max-md:flex-col">
            <div className="flex flex-col w-6/12 max-md:ml-0 max-md:w-full">
              <div className="flex z-10 flex-col grow mt-32 mr-0 font-bold max-md:mt-10 max-md:max-w-full">
                <div className="flex flex-col items-start self-end max-w-full w-[628px]">
                  <h1 className="self-stretch text-6xl leading-[73px] text-slate-700 max-md:max-w-full max-md:text-4xl max-md:leading-[58px]">
                    Committed to People Committed to{" "}
                    <span className="text-indigo-400">the Future</span>
                  </h1>
                  <p className="mt-5 text-xl leading-9 text-neutral-900 w-[465px] max-md:max-w-full">
                    An enim nullam tempor sapien gravida donec enim ipsum porta
                    justo congue magna at
                  </p>
                  <button className="gap-2.5 px-8 py-5 mt-10 text-lg text-white bg-indigo-400 rounded-2xl max-md:px-5">
                    Get Started Now
                  </button>
                </div>
                <img
                  loading="lazy"
                  src="https://cdn.builder.io/api/v1/image/assets/730124931bad4e5a81ecd722de216101/2f8dd36d1241b7fdefbbbffad94966e5d2a0b4d5139bb5b43b27c2ca97567091?apiKey=730124931bad4e5a81ecd722de216101&"
                  alt=""
                  className="object-contain mt-24 max-w-full aspect-square w-[114px] max-md:mt-10"
                />
              </div>
            </div>
            <div className="flex flex-col ml-5 w-6/12 max-md:ml-0 max-md:w-full">
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/730124931bad4e5a81ecd722de216101/9a37e38d5cb9e6367316a5a71aa65b854f33e3e4e12b36cc9b7716c09dd6c404?apiKey=730124931bad4e5a81ecd722de216101&"
                alt="Featured Image"
                className="object-contain w-full rounded-none aspect-[1.6] max-md:max-w-full"
              />
            </div>
          </div>
        </div>
      </div>
      <div className="flex flex-col justify-center items-center px-16 py-24 w-full max-md:px-5 max-md:max-w-full">
        <div className="max-w-full w-[1173px]">
          <div className="flex gap-5 max-md:flex-col">
            {stats.map((stat, index) => (
              <div
                key={index}
                className="flex flex-col w-[33%] max-md:ml-0 max-md:w-full"
              >
                <StatCard {...stat} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
