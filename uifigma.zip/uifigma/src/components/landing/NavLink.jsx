import * as React from "react";

export default function NavLink({ children, href, hasDropdown }) {
  return (
    <div className="flex gap-1 whitespace-nowrap">
      {href ? (
        <a href={href} className="grow cursor-pointer pointer-events-auto">
          {children}
        </a>
      ) : (
        <div className="grow">{children}</div>
      )}
      {hasDropdown && (
        <img
          loading="lazy"
          src="https://cdn.builder.io/api/v1/image/assets/730124931bad4e5a81ecd722de216101/b712bc6321f473e27efcbbad83ba4a70686e6c45292f7dbf04d31a42cec01426?apiKey=730124931bad4e5a81ecd722de216101&"
          alt=""
          className="object-contain shrink-0 my-auto w-4 aspect-square"
        />
      )}
    </div>
  );
}
