# Nutritionist-Food-Recognition-Gemini-Pro
Nutritionist-FoodRecognition is an intelligent food recognition system. Analyze images of dishes, identify ingredients, and receive nutritional information.
