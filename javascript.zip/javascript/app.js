// alert("sushant");
// console.log("sushant");
// document.write("sushant");
// document.write("<h1> sushant </h1>");
// prompt("please enter","susu")
// confirm("Do you want to login!")

// if-else statement
// let age=12
// if(age>=18){
// 	console.log("you can vote")
// }else{
// 	console.log("you cannot vote")
// }
// console.log("sushant")

// if-elseif-else
// const marks=99;
// if(marks>90){
// 	console.log("A++");
// }else if(marks>80){
// 	console.log("A");
// }else if(marks>70){
// 	console.log("B");
// }else if(marks>60){
// 	console.log("C");
// }else if(marks>50){
// 	console.log("D");
// }else{
// 	console.log("Fails")
// }


// nested if-else
// const age=70;
// if(age>=18){
// 	console.log("you are in if");
// 	if(age>60){
// 	console.log("you can vote");
// }
// }else{
// 	console.log("you cannot vote");
// }
// console.log("sushant systemmmm");

// ternary operater
// const marks=50;
// const result=marks>=40 ? "PASSED":"FAILED";
// console.log("result",result);

// switch statement
// const grade ="E";
// switch(grade){
// case "A":
// 	console.log("A is very good");
// 	break;
// case "B":
// 	console.log("B is good");
// 	break;
// case "C":
// 	console.log("C is nice");
// 	break;
// case "D":
// 	console.log("D is decent ");
// 	break;
// default:
// 	console.log("invalid grade");
// }

// looping
// for loop
// for(let index=0; index<1000; index=index+2){
// 	console.log("sushant", index);
// }

// for loop practice
// let cars=["BMW","TATA","TOYOTA","FIAT","MARUTI","NEXA","MAHENDRA","VOLVO"];
// let text="";
// for (let i=0; i<cars.length; i++){
// 	text += cars[i] + "<br>";
// }
// console.log(text);
// document.getElementById("demo").innerHTML = text;

// input user
// let cars1=prompt("enter 1st no.","1st no.");
// let cars2=prompt("enter 2st no.","2st no.");
// let a =prompt("enter sign");
// let car= cars1 - cars2;
// console.log(car);
// document.getElementById("demo").innerHTML= car;



// while loop
// let step=0;
// while (step<5){
// 	console.log("step", step);
// 	step += 1;
// }

// do-while loop
// let step=0;
// do{
// 	console.log('step',step);
// 	step+=1;
// }while(step<5);

// continue
// let step=0;
// while (step<5){
// 	step += 1;
// 	if(step===2){
// 		continue;
// 	}
// 	console.log("step", step);
// }


// const btn = document.querySelector("button");
// const txt = document.querySelector("p");

// btn.addEventListener("click", updateBtn);

// function updateBtn() {
//   if (btn.textContent === "Start machine") {
//     btn.textContent = "Stop machine";
//     txt.textContent = "The machine has started!";
//   } else {
//     btn.textContent = "Start machine";
//     txt.textContent = "The machine is stopped.";
//   }
// }

// const btn=document.getElementById("b1");
// const txt=document.getElementById("h");
// btn.addEventListener("click", updateBtn);
// function updateBtn(){
// 	if (btn.textContent === "Submit Document"){
// 		btn.textContent ="Document not submited";
// 		txt.textContent ="Document not Submited, stop process";
// 	} else{
// 		btn.textContent = "Submit Document";
// 		txt.textContent = "Document Submited, start process";
// 	}
// }






















// if (1==0){
// 	document.write("sushant");
// }else{
// 	// confirm("Do you want to login!")
// 	let img=document.createElement('img');
// 	img.src="boy.png";
// 	document.body.appendChild(img);
// 	img.style.borderRadius="20px";
// 	img.style.border="2px solid black";
// }

