import java.util.*;
import java.util.regex.Pattern;

class UsernameValidator {
    public static void main (String[]args){
        Pattern pattern = Pattern.compile("sushant");
        Matcher macher = pattern.matcher("sushant");
        
        if(macher.matches()){
            System.out.println("Pattern matche");
        }else{
            System.out.println("Invalid");
        }
    }
}