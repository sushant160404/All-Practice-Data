import tkinter as tk
from tkinter import *


# r = Tk()
r = Tk()
var1 = IntVar()
Checkbutton(r, text='male', variable=var1).grid(row=0, sticky=W)
var2 = IntVar()
Checkbutton(r, text='female', variable=var2).grid(row=1, sticky=W)
r.title('Sushant Tkinter')
button = tk.Button(r, text='Stop', width=50, command=r.destroy)
button.pack()
r.mainloop()
