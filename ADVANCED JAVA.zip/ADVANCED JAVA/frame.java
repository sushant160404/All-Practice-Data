import java.awt.*;

class MyFrame extends Frame {
    public MyFrame() {

    }

    public static void main(String ar[]) {
        MyFrame fr1 = new MyFrame();
        fr1.setSize(1280, 660);
        fr1.setTitle("Sushant Frame");
        fr1.setVisible(true);
    }
}