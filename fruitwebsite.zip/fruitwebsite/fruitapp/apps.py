from django.apps import AppConfig

class FruitappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fruitapp'

    # If you need to perform model operations, do it inside a method
    def ready(self):
        from .models import Fruit  # Import inside the method
        # Now you can safely use Fruit model here
