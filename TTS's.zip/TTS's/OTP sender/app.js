const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

app.use(bodyParser.json());

app.post('/send-otp', (req, res) => {
    const receivedOTP = req.body.otp;
    // Here, you can implement the code to send the OTP via SMS, email, etc.
    console.log(`Received OTP: ${receivedOTP}`);
    // Add your OTP sending logic here

    res.send('OTP sent successfully');
});

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
