document.getElementById('optInForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    // Get the entered email
    const email = document.getElementById('email').value;
  
    // You can add additional validation logic here
  
    // For this example, just log the email to the console
    console.log('Email subscribed:', email);
  
    // You can also send the email to a server for processing or integrate with an email service provider.
  });
  