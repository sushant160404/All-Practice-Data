if ('webkitSpeechRecognition' in window) {
  const recognition = new webkitSpeechRecognition();
  const startButton = document.getElementById('startButton');
  const output = document.getElementById('output');

  recognition.continuous = true;
  recognition.interimResults = true;

  // Event listener for the start button
  startButton.addEventListener('click', () => {
    startButton.textContent = 'Listening...';
    recognition.start();
  });

  // Event listener for speech recognition results
  recognition.onresult = async (event) => {
    const result = event.results[event.results.length - 1];
    const transcript = result[0].transcript;
    output.textContent = transcript;

    // Save the transcript to a PDF file
    try {
      const pdfDoc = await PDFLib.PDFDocument.create();
      const page = pdfDoc.addPage();
      const { width, height } = page.getSize();
      const font = await pdfDoc.embedFont(PDFLib.Font.Helvetica);

      page.drawText(transcript, {
        x: 50,
        y: height - 100,
        font,
        size: 12,
        color: PDFLib.rgb(0, 0, 0),
      });

      const pdfBytes = await pdfDoc.save();
      savePDF(pdfBytes);
    } catch (error) {
      console.error('Error creating PDF:', error);
      output.textContent = 'Error occurred. Please try again.';
    }
  };

  // Event listener for speech recognition errors
  recognition.onerror = (event) => {
    console.error('Speech recognition error:', event.error);
    output.textContent = 'Error occurred. Please try again.';
  };

  // Event listener for speech recognition end
  recognition.onend = () => {
    startButton.textContent = 'Start Recording';
  };

  // Function to save PDF
  const savePDF = (pdfBytes) => {
    const blob = new Blob([pdfBytes], { type: 'application/pdf' });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = 'speech_to_text_result.pdf';
    link.click();
  };
} else {
  // Handle the case when the browser doesn't support the SpeechRecognition API
  console.error('SpeechRecognition not supported');
  document.getElementById('output').textContent = 'Speech recognition is not supported in this browser.';
}
