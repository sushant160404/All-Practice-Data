// Check if the browser supports the SpeechSynthesis API
if ('speechSynthesis' in window) {
  const synthesis = window.speechSynthesis;

  // Function to speak the provided text
  function speakText() {
    const textInput = document.getElementById('textInput').value;

    if (textInput.trim() !== '') {
      const utterance = new SpeechSynthesisUtterance(textInput);
      synthesis.speak(utterance);
    }
  }
} else {
  // Handle the case when the browser doesn't support the SpeechSynthesis API
  console.error('SpeechSynthesis not supported');
}
